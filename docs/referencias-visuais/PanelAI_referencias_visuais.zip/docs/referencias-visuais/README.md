# PanelAI — Referências visuais extraídas do vídeo

Estas capturas foram extraídas do vídeo fornecido pelo idealizador do PanelAI. São referências **estruturais e funcionais**, não telas próprias do PanelAI nem um design a ser copiado literalmente. O produto deve adotar a identidade original PanelAI.

| Arquivo | Tempo aproximado | Finalidade |
|---|---:|---|
| `01_cardapio_visao_semanal.jpg` | 00:04 | Estrutura semanal com resumo de refeições |
| `02_mercado_mensal_estoque.jpg` | 00:10 | Mercado mensal e estoque por categorias |
| `03_biblioteca_receitas.jpg` | 00:23 | Biblioteca de receitas em cartões |
| `04_filtros_receitas.jpg` | 00:31 | Filtros por velocidade, proteína e composição |
| `05_planejamento_interativo.jpg` | 01:05 | Cardápio com refeições selecionadas |
| `06_seletor_receita.jpg` | 01:25 | Modal de seleção de receitas |
| `07_filtros_seletor.jpg` | 01:30 | Pesquisa e filtros dentro do modal |
| `08_lista_compras_semanal.jpg` | 01:44 | Lista semanal por dia |
| `09_lista_avulsos.jpg` | 02:00 | Inclusão de itens avulsos e checagem |
| `10_lista_semanal_detalhes.jpg` | 02:23 | Conferência da lista de compras |

## Orientações para implementação

1. Analise as capturas para identificar a hierarquia, os dados e os fluxos de cada tela.
2. Recrie o comportamento em HTML, CSS e JavaScript, com design próprio PanelAI.
3. Use identidade com panela verde-sálvia e visual minimalista.
4. Implemente layouts e interações específicos para desktop e mobile; a interface de celular **não deve ser só a versão encolhida**.
5. Os quadros originais apresentam filme de tela, distorção de perspectiva e resolução limitada. Não reproduza imperfeições de filmagem.
6. Os quadros foram recortados para mostrar a interface no monitor; consulte o vídeo original para o contexto temporal quando necessário.
